import article from './article'
import portfolioItem from './portfolioItem'
import page from './page'

export const schemaTypes = [article, portfolioItem, page]
